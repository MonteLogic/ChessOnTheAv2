// Stub file for Avalonia.Browser compatibility
// This file is required by some versions of Avalonia.Browser but doesn't contain actual functionality
// The real Avalonia functionality is provided through the .wasm files

console.log('Avalonia.js stub loaded - functionality provided by .wasm files');
